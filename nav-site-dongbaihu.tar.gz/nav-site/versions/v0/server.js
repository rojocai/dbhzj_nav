const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = path.join(__dirname, 'data.json');
const USER_FILE = path.join(__dirname, 'users.json');
const PORT = 5001;

// ===== 用户管理 =====
const SALT = 'nav_site_salt_2026';

function hashPassword(password) {
    return crypto.createHash('sha256').update(password + SALT).digest('hex');
}

function generateToken() {
    return crypto.randomBytes(32).toString('hex');
}

function readUsers() {
    try {
        if (!fs.existsSync(USER_FILE)) {
            // 首次运行，创建默认用户
            const defaultUsers = {
                users: [
                    {
                        id: 1,
                        username: 'admin',
                        password: hashPassword('admin123'),
                        created_at: new Date().toISOString(),
                        updated_at: new Date().toISOString()
                    }
                ],
                tokens: {}  // token -> username
            };
            writeUsers(defaultUsers);
            return defaultUsers;
        }
        return JSON.parse(fs.readFileSync(USER_FILE, 'utf-8'));
    } catch (e) {
        return { users: [], tokens: {} };
    }
}

function writeUsers(data) {
    fs.writeFileSync(USER_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function verifyToken(token) {
    if (!token) return null;
    const users = readUsers();
    return users.tokens[token] || null;
}

// ===== 导航数据管理 =====
function readData() {
    try {
        return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
    } catch (e) {
        return null;
    }
}

function writeData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function parseBody(req) {
    return new Promise((resolve) => {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try { resolve(JSON.parse(body)); }
            catch { resolve(null); }
        });
    });
}

function sendJSON(res, code, data) {
    res.writeHead(code, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end(JSON.stringify(data));
}

function sendFile(res, filePath, authRequired = false, token = null) {
    if (authRequired) {
        const user = verifyToken(token);
        if (!user) {
            sendJSON(res, 401, { error: '未登录，请先登录' });
            return;
        }
    }

    const ext = path.extname(filePath);
    const mime = {
        '.html': 'text/html; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.png': 'image/png',
        '.ico': 'image/x-icon',
        '.svg': 'image/svg+xml'
    };
    try {
        const content = fs.readFileSync(filePath);
        res.writeHead(200, {
            'Content-Type': mime[ext] || 'text/plain; charset=utf-8',
            'Access-Control-Allow-Origin': '*'
        });
        res.end(content);
    } catch (e) {
        sendJSON(res, 404, { error: 'File not found' });
    }
}

function parseCookies(req) {
    const cookieHeader = req.headers.cookie || '';
    const cookies = {};
    cookieHeader.split(';').forEach(c => {
        const parts = c.trim().split('=');
        if (parts.length >= 2) {
            cookies[parts[0].trim()] = parts.slice(1).join('=');
        }
    });
    return cookies;
}

const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const pathname = url.pathname;

    // CORS preflight
    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        });
        res.end();
        return;
    }

    // ===== 认证 API =====
    // 登录
    if (pathname === '/api/login' && req.method === 'POST') {
        const body = await parseBody(req);
        if (!body) { sendJSON(res, 400, { error: '请求数据无效' }); return; }

        const { username, password } = body;
        if (!username || !password) {
            sendJSON(res, 400, { error: '请输入用户名和密码' });
            return;
        }

        const users = readUsers();
        const user = users.users.find(u => u.username === username);
        
        if (!user || user.password !== hashPassword(password)) {
            sendJSON(res, 401, { error: '用户名或密码错误' });
            return;
        }

        // 生成 token
        const token = generateToken();
        users.tokens[token] = username;
        writeUsers(users);

        // 返回 token（通过 cookie + body）
        res.writeHead(200, {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Set-Cookie': `nav_token=${token}; HttpOnly; Path=/; Max-Age=86400; SameSite=Lax`
        });
        res.end(JSON.stringify({
            success: true,
            token: token,
            user: { username: user.username }
        }));
        return;
    }

    // 验证 token
    if (pathname === '/api/verify' && req.method === 'GET') {
        const cookies = parseCookies(req);
        const authHeader = req.headers.authorization;
        const token = cookies.nav_token || (authHeader && authHeader.replace('Bearer ', ''));
        
        const username = verifyToken(token);
        if (username) {
            sendJSON(res, 200, { success: true, user: { username } });
        } else {
            sendJSON(res, 401, { error: '未登录' });
        }
        return;
    }

    // 修改密码
    if (pathname === '/api/change-password' && req.method === 'POST') {
        const cookies = parseCookies(req);
        const authHeader = req.headers.authorization;
        const token = cookies.nav_token || (authHeader && authHeader.replace('Bearer ', ''));
        const username = verifyToken(token);
        
        if (!username) {
            sendJSON(res, 401, { error: '未登录' });
            return;
        }

        const body = await parseBody(req);
        if (!body) { sendJSON(res, 400, { error: '请求数据无效' }); return; }

        const { oldPassword, newPassword } = body;
        if (!oldPassword || !newPassword) {
            sendJSON(res, 400, { error: '请填写旧密码和新密码' });
            return;
        }
        if (newPassword.length < 6) {
            sendJSON(res, 400, { error: '新密码至少6位' });
            return;
        }

        const users = readUsers();
        const user = users.users.find(u => u.username === username);
        
        if (!user || user.password !== hashPassword(oldPassword)) {
            sendJSON(res, 401, { error: '旧密码错误' });
            return;
        }

        // 如果修改的是 admin 账号密码，也同时修改用户名
        if (body.newUsername && body.newUsername.trim()) {
            const newUsername = body.newUsername.trim();
            // 检查新用户名是否被占用
            const existing = users.users.find(u => u.username === newUsername && u.username !== username);
            if (existing) {
                sendJSON(res, 400, { error: '用户名已存在' });
                return;
            }
            user.username = newUsername;
            // 更新所有 token 记录
            const oldTokens = Object.keys(users.tokens);
            oldTokens.forEach(t => {
                if (users.tokens[t] === username) {
                    users.tokens[t] = newUsername;
                }
            });
        }

        user.password = hashPassword(newPassword);
        user.updated_at = new Date().toISOString();
        writeUsers(users);

        sendJSON(res, 200, { success: true, message: '密码修改成功', username: user.username });
        return;
    }

    // 退出登录
    if (pathname === '/api/logout' && req.method === 'POST') {
        const cookies = parseCookies(req);
        const authHeader = req.headers.authorization;
        const token = cookies.nav_token || (authHeader && authHeader.replace('Bearer ', ''));
        
        if (token) {
            const users = readUsers();
            delete users.tokens[token];
            writeUsers(users);
        }

        res.writeHead(200, {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Set-Cookie': 'nav_token=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax'
        });
        res.end(JSON.stringify({ success: true }));
        return;
    }

    // ===== 导航数据 API（需要验证） =====
    if (pathname === '/api/data' && req.method === 'GET') {
        const data = readData();
        if (data) sendJSON(res, 200, data);
        else sendJSON(res, 500, { error: 'Failed to read data' });
        return;
    }

    if (pathname === '/api/data' && req.method === 'POST') {
        // 需要验证
        const cookies = parseCookies(req);
        const authHeader = req.headers.authorization;
        const token = cookies.nav_token || (authHeader && authHeader.replace('Bearer ', ''));
        const user = verifyToken(token);
        
        if (!user) {
            sendJSON(res, 401, { error: '未登录，无法保存' });
            return;
        }

        const body = await parseBody(req);
        if (body) {
            writeData(body);
            sendJSON(res, 200, { success: true });
        } else {
            sendJSON(res, 400, { error: 'Invalid JSON' });
        }
        return;
    }

    // ===== 静态文件 =====
    if (pathname === '/' || pathname === '/index.html') {
        sendFile(res, path.join(__dirname, 'index.html'));
        return;
    }

    if (pathname === '/admin.html' || pathname === '/login.html') {
        sendFile(res, path.join(__dirname, 'admin.html'));
        return;
    }

    if (pathname === '/data.json') {
        sendFile(res, DATA_FILE);
        return;
    }

    sendJSON(res, 404, { error: 'Not found' });
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`API server running on http://0.0.0.0:${PORT}`);
});
